#!/usr/bin/env bash
#SBATCH --job-name=BCR_MiXCR
#SBATCH --partition=AMD9554-common
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --mem=16G
#SBATCH --time=06:00:00
#SBATCH --output=BCR_MiXCR_%j.log
#SBATCH --error=BCR_MiXCR_%j.err

set -eo pipefail
test -n "${SLURM_JOB_ID:-}"
cd "${SLURM_SUBMIT_DIR}"
source "$HOME/miniforge3/etc/profile.d/conda.sh"
conda activate immune-mixcr

export JAVA_TOOL_OPTIONS="-Xmx12g"

sample=DChu_T7_pbmc_d7COVID2_2
raw=/home/STUDY/FBMF/bioinformatics/immuno/hw
out="$PWD/outputs/bcr/mixcr/job_${SLURM_JOB_ID}"
preset=milab-human-rna-ig-umi-multiplex

mkdir -p "$out"
mixcr --version

mixcr exportPreset --preset-name "$preset" \
  --assemble-clonotypes-by CDR3 \
  --split-clones-by V --split-clones-by J \
  "$out/preset.yaml"

mixcr analyze "$preset" \
  --threads "$SLURM_CPUS_PER_TASK" \
  --assemble-clonotypes-by CDR3 \
  --split-clones-by V --split-clones-by J \
  "$raw/${sample}_R1.fastq.gz" \
  "$raw/${sample}_R2.fastq.gz" \
  "$out/$sample"

printf 'Results: %s\n' "$out"
